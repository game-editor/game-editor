/*
 *  start.cpp
 *  gameEditor
 *
 *  Created by Andreas on 5/9/10.
 *  Copyright 2010 Visionware. All rights reserved.
 *
 */


void foo(void)
{

}